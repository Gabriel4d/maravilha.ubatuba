const botao = document.querySelector("#botao_chamativo");
const modal = document.querySelector("#modal_reserva");
const fechar = document.querySelector("#fechar_modal");

botao.addEventListener("click", function() {
    modal.style.display = "flex";
});

fechar.addEventListener("click", function() {
    modal.style.display = "none";
});